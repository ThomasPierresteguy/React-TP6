import { useState } from "react";

function App() {
  const [tareas, setTareas] = useState([
    { descripcion: 'Organizar el asadp', completada: true },
    { descripcion: 'Comprar la carne', completada: true },
    { descripcion: 'Prender el fuego', completada: false },
  ]);
  const [nuevaTarea, setNuevaTarea] = useState('');

  const agregarTarea = (e) => {
    e.preventDefault();
    const nuevaTareaObj = { descripcion: nuevaTarea, completada: false };
    setTareas([...tareas, nuevaTareaObj]);
    setNuevaTarea('');
  };

  const marcarCompletada = (descripcion) => {
    const nuevasTareas = tareas.map(t => {
      if (t.descripcion === descripcion) {
        return { ...t, completada: !t.completada };
      }
      return t;
    });
    setTareas(nuevasTareas);
  };

  const borrar = (descripcion) => {
    const nuevasTareas = tareas.filter(t => t.descripcion !== descripcion);
    setTareas(nuevasTareas);
  };

  return (
    <div>
      <table border="1">
        <thead>
          <tr>
            <th>Descripción</th>
            <th>Completada</th>
            <th>Borrar</th>
          </tr>
        </thead>
        <tbody>
          {tareas.map(t => (
            <tr key={t.descripcion}>
              <td>{t.descripcion}</td>
              <td>
                <button onClick={() => marcarCompletada(t.descripcion)}>
                  {t.completada ? 'Si' : 'No'}
                </button>
              </td>
              <td>
                <button onClick={() => borrar(t.descripcion)}>Borrar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <form onSubmit={agregarTarea}>
        <input type="text" value={nuevaTarea} onChange={(e) => setNuevaTarea(e.target.value)} />
        <button type="submit">Agregar tarea</button>
      </form>
    </div>
  );
}

export default App;
